local variables = {};

variables.terminal = "termite";
variables.modKey = "Mod4";
variables.layouts = {};

return variables;
